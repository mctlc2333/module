#!/system/bin/sh

TARGET_PACKAGE_FILE="${MODPATH}/target_package.txt"

ui_print "================================"
ui_print "AutoClearStorage 模块安装"
ui_print "作者: mc13"
ui_print "================================"
ui_print "按音量+ 从列表选择应用"
ui_print "按音量- 安装后手动配置"
ui_print "================================"

# 按键检测
while true; do
    key=$(getevent -qlc 1 | grep -oE 'KEY_[A-Z_]+' | head -1)
    case "$key" in
        KEY_VOLUMEUP)
            ui_print "已选择: 从列表选择应用"
            # 跳转到列表选择
            break
            ;;
        KEY_VOLUMEDOWN)
            ui_print "已选择: 安装后手动配置"
            echo "com.example.app" > "$TARGET_PACKAGE_FILE"
            ui_print "================================"
            ui_print "安装完成！"
            ui_print "请编辑文件设置包名:"
            ui_print "$TARGET_PACKAGE_FILE"
            exit 0
            ;;
    esac
    sleep 0.1
done

# 列表选择（用独立变量，不用数组）
ui_print "================================"
ui_print "请选择要清除的应用:"
ui_print "按音量+ 切换  按音量- 确认"
ui_print "================================"

APP_NAME1="微信"
APP_PKG1="com.tencent.mm"
APP_NAME2="QQ"
APP_PKG2="com.tencent.mobileqq"
APP_NAME3="抖音"
APP_PKG3="com.ss.android.ugc.aweme"
APP_NAME4="淘宝"
APP_PKG4="com.taobao.taobao"
APP_NAME5="支付宝"
APP_PKG5="com.eg.android.AlipayGphone"
APP_NAME6="拼多多"
APP_PKG6="com.xunmeng.pinduoduo"
APP_NAME7="URnetwork"
APP_PKG7="com.bringyour.network"
TOTAL=7
SELECTION=1

while true; do
    ui_print ""
    
    if [ $SELECTION -eq 1 ]; then
        ui_print " → 1. $APP_NAME1"
    else
        ui_print "   1. $APP_NAME1"
    fi
    
    if [ $SELECTION -eq 2 ]; then
        ui_print " → 2. $APP_NAME2"
    else
        ui_print "   2. $APP_NAME2"
    fi
    
    if [ $SELECTION -eq 3 ]; then
        ui_print " → 3. $APP_NAME3"
    else
        ui_print "   3. $APP_NAME3"
    fi
    
    if [ $SELECTION -eq 4 ]; then
        ui_print " → 4. $APP_NAME4"
    else
        ui_print "   4. $APP_NAME4"
    fi
    
    if [ $SELECTION -eq 5 ]; then
        ui_print " → 5. $APP_NAME5"
    else
        ui_print "   5. $APP_NAME5"
    fi
    
    if [ $SELECTION -eq 6 ]; then
        ui_print " → 6. $APP_NAME6"
    else
        ui_print "   6. $APP_NAME6"
    fi
    
    if [ $SELECTION -eq 7 ]; then
        ui_print " → 7. $APP_NAME7"
    else
        ui_print "   7. $APP_NAME7"
    fi
    
    ui_print "================================"
    
    key=$(getevent -qlc 1 | grep -oE 'KEY_[A-Z_]+' | head -1)
    case "$key" in
        KEY_VOLUMEUP)
            SELECTION=$((SELECTION % TOTAL + 1))
            ;;
        KEY_VOLUMEDOWN)
            break
            ;;
    esac
    sleep 0.1
done

# 设置选中的包名
case $SELECTION in
    1) PKG="$APP_PKG1"; NAME="$APP_NAME1" ;;
    2) PKG="$APP_PKG2"; NAME="$APP_NAME2" ;;
    3) PKG="$APP_PKG3"; NAME="$APP_NAME3" ;;
    4) PKG="$APP_PKG4"; NAME="$APP_NAME4" ;;
    5) PKG="$APP_PKG5"; NAME="$APP_NAME5" ;;
    6) PKG="$APP_PKG6"; NAME="$APP_NAME6" ;;
    7) PKG="$APP_PKG7"; NAME="$APP_NAME7" ;;
esac

echo "$PKG" > "$TARGET_PACKAGE_FILE"
ui_print "================================"
ui_print "已选择: $NAME"
ui_print "包名: $PKG"
ui_print "================================"
ui_print "安装完成！"