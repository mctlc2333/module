#!/system/bin/sh
MODDIR=${0%/*}
TARGET_PACKAGE_FILE="${MODDIR}/target_package.txt"
CONFIG_MODE_FILE="${MODDIR}/config_mode.txt"

# 读取包名
if [ -f "$TARGET_PACKAGE_FILE" ]; then
    TARGET_PACKAGE=$(cat "$TARGET_PACKAGE_FILE")
else
    TARGET_PACKAGE="com.example.app"
fi

LAST_CLEAR_FILE="${MODDIR}/last_clear_date"

get_current_days() {
    date +%s
}

check_and_clear() {
    # 如果是手动模式且包名还是默认值，跳过清除并记录日志
    if [ -f "$CONFIG_MODE_FILE" ]; then
        MODE=$(cat "$CONFIG_MODE_FILE")
        if [ "$MODE" = "manual" ] && [ "$TARGET_PACKAGE" = "com.example.app" ]; then
            log -p w -t "AutoClearStorage" "请先编辑配置文件设置目标包名"
            return
        fi
    fi
    
    current_days=$(get_current_days)
    [ -f "$LAST_CLEAR_FILE" ] && last_clear=$(cat "$LAST_CLEAR_FILE") || last_clear=0
    time_diff=$(( (current_days - last_clear) / 86400 ))
    
    if [ $time_diff -ge 20 ]; then
        pm clear "$TARGET_PACKAGE"
        echo "$current_days" > "$LAST_CLEAR_FILE"
        log -p i -t "AutoClearStorage" "已清除 $TARGET_PACKAGE 的存储空间"
    fi
}

sleep 60
check_and_clear