#!/system/bin/sh
MODDIR=${0%/*}
rm -f "${MODDIR}/last_clear_date"
rm -f "${MODDIR}/target_package.txt"
rm -f "${MODDIR}/config_mode.txt"
ui_print "AutoClearStorage 已卸载，所有记录已清理"
return 0