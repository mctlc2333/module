// 模块路径
const MODULE_PATH = '/data/adb/modules/autoclearstorage';

// 通用请求函数（使用 KsuWebUI 的 API）
async function apiRequest(action, params = {}) {
    // KsuWebUI 提供 root 权限的 API
    return new Promise((resolve, reject) => {
        if (window.KsuWebUI && window.KsuWebUI.exec) {
            // 使用 KsuWebUI 的原生 API
            window.KsuWebUI.exec(action, params, (result) => {
                resolve(result);
            });
        } else {
            reject(new Error('KsuWebUI API 不可用'));
        }
    });
}

// 读取文件
async function readFile(path) {
    return new Promise((resolve) => {
        if (window.KsuWebUI && window.KsuWebUI.readFile) {
            window.KsuWebUI.readFile(path, (content) => {
                resolve(content);
            });
        } else {
            resolve(null);
        }
    });
}

// 写入文件
async function writeFile(path, content) {
    return new Promise((resolve) => {
        if (window.KsuWebUI && window.KsuWebUI.writeFile) {
            window.KsuWebUI.writeFile(path, content, (success) => {
                resolve(success);
            });
        } else {
            resolve(false);
        }
    });
}

// 执行命令
async function execCommand(cmd) {
    return new Promise((resolve) => {
        if (window.KsuWebUI && window.KsuWebUI.exec) {
            window.KsuWebUI.exec(cmd, (output) => {
                resolve(output);
            });
        } else {
            resolve('');
        }
    });
}

// 显示状态消息
function showStatus(title, message, type = 'info') {
    const statusCard = document.getElementById('statusCard');
    const statusTitle = document.getElementById('statusTitle');
    const statusMessage = document.getElementById('statusMessage');
    
    statusCard.className = `status-card ${type}`;
    statusTitle.textContent = title;
    statusMessage.textContent = message;
    statusCard.style.display = 'block';
    
    setTimeout(() => {
        statusCard.style.display = 'none';
    }, 5000);
}

// 加载当前配置信息
async function loadConfig() {
    try {
        const packageContent = await readFile(`${MODULE_PATH}/target_package.txt`);
        let currentPackage = 'com.example.app';
        if (packageContent) {
            currentPackage = packageContent.trim();
        }
        document.getElementById('currentPackage').textContent = currentPackage;
        
        const lastClearContent = await readFile(`${MODULE_PATH}/last_clear_date`);
        let lastClearTimestamp = 0;
        if (lastClearContent) {
            lastClearTimestamp = parseInt(lastClearContent) || 0;
        }
        
        if (lastClearTimestamp > 0) {
            const lastDate = new Date(lastClearTimestamp * 1000);
            document.getElementById('lastClearTime').textContent = lastDate.toLocaleString('zh-CN');
            
            const now = Math.floor(Date.now() / 1000);
            const daysPassed = Math.floor((now - lastClearTimestamp) / 86400);
            const daysLeft = Math.max(0, 20 - daysPassed);
            document.getElementById('nextClearDays').textContent = `${daysLeft} 天后`;
        } else {
            document.getElementById('lastClearTime').textContent = '从未清理';
            document.getElementById('nextClearDays').textContent = '首次运行';
        }
        
        await checkStorage(currentPackage);
        
    } catch (error) {
        console.error('加载配置失败:', error);
        showStatus('加载失败', '无法读取配置文件', 'error');
    }
}

// 检查应用存储空间
async function checkStorage(packageName = null) {
    if (!packageName) {
        const pkgElement = document.getElementById('currentPackage');
        packageName = pkgElement.textContent;
    }
    
    if (!packageName || packageName === 'com.example.app') {
        document.getElementById('appStorageSize').textContent = '未设置';
        return;
    }
    
    document.getElementById('appStorageSize').innerHTML = '<span class="loading"></span>';
    
    try {
        const output = await execCommand(`du -s /data/data/${packageName} 2>/dev/null | cut -f1`);
        if (output && output.trim()) {
            const sizeKB = parseInt(output.trim());
            const sizeMB = (sizeKB / 1024).toFixed(2);
            document.getElementById('appStorageSize').textContent = `${sizeMB} MB`;
        } else {
            document.getElementById('appStorageSize').textContent = '无数据或应用未安装';
        }
    } catch (error) {
        console.error('检查存储失败:', error);
        document.getElementById('appStorageSize').textContent = '获取失败';
    }
}

// 更改包名
async function changePackage(newPackage) {
    if (!newPackage || newPackage.trim() === '') {
        showStatus('错误', '包名不能为空', 'error');
        return false;
    }
    
    try {
        const success = await writeFile(`${MODULE_PATH}/target_package.txt`, newPackage.trim());
        if (success) {
            showStatus('成功', `包名已更改为: ${newPackage}`, 'success');
            await loadConfig();
            return true;
        } else {
            throw new Error('写入失败');
        }
    } catch (error) {
        showStatus('失败', '更改包名失败: ' + error.message, 'error');
        return false;
    }
}

// 立即清除应用存储
async function clearNow() {
    const currentPackage = document.getElementById('currentPackage').textContent;
    
    if (!currentPackage || currentPackage === 'com.example.app') {
        showStatus('错误', '请先设置目标应用包名', 'error');
        return;
    }
    
    showStatus('执行中', `正在清除 ${currentPackage} 的存储空间...`, 'info');
    
    try {
        const output = await execCommand(`pm clear ${currentPackage}`);
        
        if (output && output.includes('Success')) {
            const now = Math.floor(Date.now() / 1000);
            await writeFile(`${MODULE_PATH}/last_clear_date`, now.toString());
            showStatus('成功', `已清除 ${currentPackage} 的存储空间`, 'success');
            await loadConfig();
        } else {
            showStatus('失败', `清除失败: ${output || '未知错误'}`, 'error');
        }
    } catch (error) {
        showStatus('错误', '执行清除命令失败: ' + error.message, 'error');
    }
}

// 模态框控制
const modal = document.getElementById('modal');
const packageInput = document.getElementById('packageInput');

function openModal() {
    modal.classList.add('show');
    packageInput.value = document.getElementById('currentPackage').textContent;
    packageInput.focus();
}

function closeModal() {
    modal.classList.remove('show');
}

// 事件绑定
document.getElementById('btnChangePackage').addEventListener('click', openModal);
document.getElementById('btnClearNow').addEventListener('click', clearNow);
document.getElementById('btnCheckStorage').addEventListener('click', () => {
    const pkg = document.getElementById('currentPackage').textContent;
    checkStorage(pkg);
});
document.getElementById('modalClose').addEventListener('click', closeModal);
document.getElementById('btnCancel').addEventListener('click', closeModal);
document.getElementById('btnConfirm').addEventListener('click', async () => {
    const newPackage = packageInput.value.trim();
    if (newPackage) {
        await changePackage(newPackage);
        closeModal();
    }
});

// 点击模态框背景关闭
modal.addEventListener('click', (e) => {
    if (e.target === modal) {
        closeModal();
    }
});

// 预设按钮事件
document.querySelectorAll('.preset-btn').forEach(btn => {
    btn.addEventListener('click', () => {
        const pkg = btn.getAttribute('data-pkg');
        packageInput.value = pkg;
    });
});

// 页面加载
document.addEventListener('DOMContentLoaded', loadConfig);